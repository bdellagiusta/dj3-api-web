
export const ID_TARGET = '21115'

export const RELAY_TARGET = '21117'
