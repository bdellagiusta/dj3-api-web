

export const ENABLE_STATUS = 1
export const DISABLE_STATUS = 2
