<template>
  <router-view/>
</template>
<script>
  import { defineComponent, ref, onMounted } from 'vue'

  export default defineComponent({
    props: {},
    setup (props) {
    },
    created () {

    },
  })


</script>
<style>
</style>
